 import javax.swing.JOptionPane;

class lawn {

    double length;
    double width;

    public lawn() {

    }

    public lawn(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public double calcsize() {
        return this.length * this.width;
    }

    public double weekfee() {
        double size = calcsize();
        if (size < 4000) {
            return 25;
        }
        if (size >= 4000 && size < 6000) {
            return 35;
        }
        return 50;
    }

    public double getlength() {
        return length;
    }

    public void setlength(double length) {
        this.length = length;
    }

    public double getwidth() {
        return width;
    }

    public void setwidth(double width) {
        this.width = width;
    }
}

class program {

    public static void main(String[] args) {
        double length = Double.parseDouble(JOptionPane.showInputDialog("Lawn Length: "));
        double width = Double.parseDouble(JOptionPane.showInputDialog("Lawn Width: "));
        lawn lawn = new lawn(length, width);
        double weekseasonalfee20 = lawn.weekfee() * 20;
        String output = "Your lawn is " + lawn.calcsize() + "square feet.\n";
        output += "20-week-seasonal-fee: R" + weekseasonalfee20 + "\n";
        output += "Your payment is 20 times per year: R" + lawn.weekfee() + "\n";

        JOptionPane.showMessageDialog(null, output);
    }
}