/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package furniture.java;

import java.util.Scanner;

/**
 *
 * @author Christopher
 */
public class FurnitureJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Choose the type of table");
        System.out.println("------------------------");
        System.out.println("1. Pine");
        System.out.println("2. Oak");
        System.out.println("3. Mahogany");
        System.out.println("------------------------");
        
        int count=0;
        
        for (int i = 0; i < 3; i++) {
        
        if (count<3) {
            
        Scanner scanner = new Scanner(System.in);
        byte option =scanner.nextByte();
        
        
        if(option== 1){
        System.out.println("Pine (R100)");
        count=3;
        }else if(option==2){
        System.out.println("Oak (R225)"); 
        count=3;
        }else if(option==3){
        System.out.println("Mahogany (R310)");
        count=3;
        }else 
        System.out.println("No valid selection (R0)"); 
        count=count+1;
          }
        }
    }
                 
            
    }
    

