
package artistsearchoop;

import java.util.Arrays;
import javax.swing.JOptionPane;
import java.util.Scanner;

class  salesSummary extends Abstract{
    @Override
    public void anotherMethod(){
        
              System.out.println("Artist Name  " +
"Artist CD sales  " +
"Artist DVD Sales  " +
"Artist Blu Ray Sales "); 
              
                       
         System.out.println("___________________________________________________"
                 + "___________________________________________________________________\n");
        
     int artistSales[][] = {
            {900000, 800000, 500000}, 
            {700000, 500000, 500000}, 
            {800000, 100000, 50000}, 
            {100000, 200000, 200000},
            {300000, 100000, 50000},
        };
      
      String[] artistNames = {"Master KG","DJ B Coffee", "Bruno Mars", "F Fighters", "T Swift"};
      
      int rowSum= artistSales.length;
      int colSum= artistSales[0].length;
      int[] total ;
      total= new int[10];
      
        for (int i = 0; i < rowSum; i++) { //this equals to the row in our matrix.
            System.out.print((i+1)+"."+artistNames[i]+"      ");
         for (int j = 0; j < colSum; j++) { //this equals to the column in each row.
            if (j<2){
            System.out.format("%-20s",artistSales[i][j]);
            total[j]=artistSales[i][j]; 
            
            }else
            {
            System.out.print(artistSales[i][j]);
            total[j]=artistSales[i][j]; 
            }
         }
         
         System.out.println(); //change line on console as row comes to end in the matrix.
         
      }
        
      System.out.println("___________________________________________________"
                 + "___________________________________________________________________");
      System.out.println("Total:         2800000            1700000             1300000");

        
    }
    
}

class  subclass extends salesSummary{
     int index=0;  
     
     @Override
     public void anotherMethod(){ 
    
    Scanner sc = new Scanner(System.in);
    System.out.println("Select a number between 0 and 6");
    boolean test =true;
    int testnum=0;
    
    
         while (test) {            
        int select = sc.nextInt();
        switch (select) {
        case 0:
                break;
        case 1:
            System.out.println("Artist Name: Master KG");
            System.out.println("Artist CD sale: 900000");
            System.out.println("Artist DVD Sale: 800000");
            System.out.println("Artist Blu Ray Sale: 500000");
            System.out.println("Total: 2200000");
            break;
        case 2:
             System.out.println("Artist Name: DJ B Coffee");
            System.out.println("Artist CD sale: 700000");
            System.out.println("Artist DVD Sale: 500000");
            System.out.println("Artist Blu Ray Sale: 500000");
            System.out.println("Total: 1700000");
            break;
        case 3:
             System.out.println("Artist Name: Bruno Mars");
            System.out.println("Artist CD sale: 800000");
            System.out.println("Artist DVD Sale: 100000");
            System.out.println("Artist Blu Ray Sale: 50000");
            System.out.println("Total: 950000");
            break;
        case 4:
             System.out.println("Artist Name: F Fighters");
            System.out.println("Artist CD sale: 100000");
            System.out.println("Artist DVD Sale: 200000");
            System.out.println("Artist Blu Ray Sale: 200000");
            System.out.println("Total: 500000");
            break;
        case 5:
            System.out.println("Artist Name: T Swift");
            System.out.println("Artist CD sale: 300000");
            System.out.println("Artist DVD Sale: 100000");
            System.out.println("Artist Blu Ray Sale: 500000");
            System.out.println("Total: 450000");
            break;
        case 6:
                break;
        default:
            testnum++;
            if (select<0){
                    test=false;
                    }
            System.out.println("Choose between 1 to 5!");
            
            if (testnum==6){
                    test=false;
                    }

        }
         }
    
        
 }
     
     
     
     public void printMessage(){

    // this calls overriding method
    anotherMethod();

    // this calls overridden method
    super.anotherMethod();
  }
     
  }

abstract class Abstract{
   public void myMethod(){
      int rowSum=0;
      int colSum=0;     
   }
   abstract public void anotherMethod();
}

public class ArtistSearchOop extends salesSummary{
    public static void main(String[] args) {
    
    salesSummary artistList= new salesSummary();
    artistList.anotherMethod();
    
    subclass sub = new subclass();
    sub.anotherMethod();

    }
    
    
    
}
