import java.text.NumberFormat;  
import java.util.*;  
import java.awt.Component;
import javax.swing.JOptionPane;
import java.util.Scanner;
import javax.swing.*; 
        
public class Customer {
  public void calculate_repayment(){
  String custName;
  String custNum;
  // new fields!
  int prodPrice;
  int monthNum;
  int monPay;
  }
  // new parameters that correspond to the new fields
  public Customer(String custName,String custNum, int prodPrice, int monthNum,int monPay) {
      
      String name = custName;
      String number = custNum;
    // assign new parameters to the new fields
    int price = prodPrice;
    int month = monthNum;
    int monthPay= monPay;
    int total=0;
    boolean exeption=true;
    Component frame = null;
    
    name=JOptionPane.showInputDialog("Please enter the customer name","Customer Name"); 
    number=JOptionPane.showInputDialog("Please enter the customer contact number","Customer Number");
  
    
      while (exeption) {          
          
      
    try {
    price=Integer.parseInt(JOptionPane.showInputDialog("Please enter the price of the product","Product Price"));
    } catch (NumberFormatException ex) {
         JOptionPane.showMessageDialog(frame,"Enter valid integer ");
         price=Integer.parseInt(JOptionPane.showInputDialog("Please enter the price of the product","Product Price"));
    }finally{
      if (!(price==' ')){
          exeption=false;
      }
    }
    
    
    try {
    month=Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of repayment months","Number of Months"));
    }catch (NumberFormatException ex) {
     JOptionPane.showMessageDialog(frame,"Enter valid integer ");
     month=Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of repayment months","Number of Months"));
    }finally{
      if (!(month==' ')){
          exeption=false;
      }
    }
      }
    
      
    if (month>3){
    total=(int) Math.round(price*0.25)+price;
    }else{
    total=price;    
    }
    monthPay=(int) Math.round(total/month);
    JOptionPane.showMessageDialog(frame,"Customer Name: "+name+"\n"+
                                       "Customer Number: "+number+"\n"+
                                       "Product Price: R"+price+"\n"+
                                       "Number of Months: "+month+"\n"+
                                        "Monthly Repayment Amount: R"+monthPay+"\n"+
                                           "Total Due: R"+total);
      }
 
  
  
  class Finance_Period extends Customer{
    @Override
     public void calculate_repayment(){
      calculate_repayment();  
     }  
  }
 
  public static void main(String[] args) {
    // new values passed into the method call
   Customer newCus = new Customer(" ", " ", 0,0,0);
 
  }
}
