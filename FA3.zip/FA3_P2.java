import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Number of loans:");
        double[] loans = new double[in.nextInt()];
        for (int i = 0; i < loans.length; i++) {
            System.out.println("Loan "+String.valueOf(i+1));
            loans[i] = in.nextDouble();
        }
        System.out.println("Totals:");
        for (int i = 0; i < loans.length; i++) {
            System.out.println("Amount owed on loan "+String.valueOf(i+1)+": R"+ Math.round(loans[i] * 1.0775));
        }
    }
}