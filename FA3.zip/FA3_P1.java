/*Christopher Muller 10395*/
package fa3_p1;

import javax.swing.JOptionPane;
import java.util.Scanner;


enum Day {
	SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}


class enumDayMood {
	void telDayMood(Day day) {
		
		switch (day) {
		case MONDAY:
			JOptionPane.showMessageDialog(null, "Mondays are bad.");
			break;
		case FRIDAY:
			JOptionPane.showMessageDialog(null, "Fridays are better.");
			break;
		case SATURDAY:
		case SUNDAY:
			JOptionPane.showMessageDialog(null, "Weekends are best.");
			break;
		default:
			JOptionPane.showMessageDialog(null, "Midweek days are so-so.");
			break;
		}


	}


}
public class FA3_P1 {
	public static void main(String[] args) {
                enumDayMood enumDayMood=new enumDayMood();
                enumDayMood.telDayMood(Day.SATURDAY);
		enumDayMood.telDayMood(Day.FRIDAY);
		enumDayMood.telDayMood(Day.TUESDAY);
		enumDayMood.telDayMood(Day.MONDAY);      
                
	}
}



