import javax.swing.*;

public class Student {

    int studentNumber;
    double testResult;
    double assignmentResult;
    double examResult;

    public Student() {
    }

    public Student(int studentNumber, double testResult, double assignmentResult, double examResult) {
        this.studentNumber = studentNumber;
        this.testResult = testResult;
        this.assignmentResult = assignmentResult;
        this.examResult = examResult;
    }

    public void getStudentNumber() {
        try {
            studentNumber = Integer.parseInt(JOptionPane.showInputDialog("Enter student number: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getStudentNumber();
        }
    }

    public void getTestResult() {
        try {
            testResult = Double.parseDouble(JOptionPane.showInputDialog("Enter test result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getTestResult();
        }
    }

    public void getAssignmentResult() {
        try {
            assignmentResult = Double.parseDouble(JOptionPane.showInputDialog("Enter assignment result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getAssignmentResult();
        }
    }

    public void getExamResult() {
        try {
            examResult = Double.parseDouble(JOptionPane.showInputDialog("Enter exam result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getExamResult();
        }
    }
    
}



class Student_Report extends Student {

    public Student_Report() {
    }

    public Student_Report(int studentNumber, double testResult, double assignmentResult, double examResult) {
        super(studentNumber, testResult, assignmentResult, examResult);
    }

    @Override
    public void getStudentNumber() {
        try {
            studentNumber = Integer.parseInt(JOptionPane.showInputDialog("Enter student number: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getStudentNumber();
        }
    }

    @Override
    public void getTestResult() {
        try {
            testResult = Double.parseDouble(JOptionPane.showInputDialog("Enter test result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getTestResult();
        }
    }

    @Override
    public void getAssignmentResult() {
        try {
            assignmentResult = Double.parseDouble(JOptionPane.showInputDialog("Enter assignment result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getAssignmentResult();
        }
    }

    @Override
    public void getExamResult() {
        try {
            examResult = Double.parseDouble(JOptionPane.showInputDialog("Enter exam result: "));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter a valid number");
            getExamResult();
        }
    }

    public void print_report() {
        JOptionPane.showMessageDialog(null,
                "Student number: " + studentNumber + System.lineSeparator()
                + "Test: " + testResult + System.lineSeparator()
                + "Assignment: " + assignmentResult + System.lineSeparator()
                + "Exam: " + examResult);
    }
}

class Test {

    public static void main(String[] args) {
        Student_Report stu = new Student_Report();
        stu.getStudentNumber();
        stu.getTestResult();
        stu.getAssignmentResult();

        stu.getExamResult();
        stu.print_report();
    }
}