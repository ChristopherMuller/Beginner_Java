package dragonkiller;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class DragonKiller {

    public static int removeSpace(String str){
        str = str.replaceAll(" ", "");
        System.out.println(str);
        return str.length();
    }

    public static int[] Killed(int[] arrayDragon, Scanner in){
        int ch = in.nextInt();

        for (int i = 0; i < arrayDragon .length; i++) {
            if(ch == arrayDragon [i]){
                arrayDragon [i] = 0;
            }
        }
        return arrayDragon;
    }
    
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        String name = in.nextLine();
        Random rand = new Random();

        int[] arrayDragon  = new int[removeSpace(name)];

        for (int i = 0; i < arrayDragon.length; i++) {
            arrayDragon[i] = rand.nextInt(10, 51);
        }

        System.out.println(Arrays.toString(arrayDragon));

        arrayDragon = Killed(arrayDragon, in);

        System.out.println(Arrays.toString(arrayDragon));
    }
}
